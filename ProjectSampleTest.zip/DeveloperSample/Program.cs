﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
public class Test
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Hello, World!");
    }
}